// ============================================
// 🔥 FIREBASE CONFIGURATION
// ============================================
// Neeche diye gaye values ko apne Firebase project
// ke values se replace karein.
// Guide mein step-by-step bataya hai kaise milega.
// ============================================

import { initializeApp } from "firebase/app";
import { getDatabase, ref, set, get, remove, onValue } from "firebase/database";

const firebaseConfig = {
  apiKey: "YAHAN_APNA_API_KEY_DAALEIN",
  authDomain: "YAHAN_APNA_PROJECT.firebaseapp.com",
  databaseURL: "https://YAHAN_APNA_PROJECT-default-rtdb.firebaseio.com",
  projectId: "YAHAN_APNA_PROJECT_ID",
  storageBucket: "YAHAN_APNA_PROJECT.appspot.com",
  messagingSenderId: "YAHAN_SENDER_ID",
  appId: "YAHAN_APP_ID"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

export { db, ref, set, get, remove, onValue };
