# 🏥 MachineTrack Pro — Setup Guide (Hindi)

## Aapko Kya Kya Chahiye

Aapko **3 free accounts** banane hain (sab free hai):
1. **GitHub** — Code store karne ke liye
2. **Firebase** — Database (data store) ke liye  
3. **Vercel** — Website live karne ke liye

---

## STEP 1: GitHub Account Banao

1. Browser mein jao: **https://github.com**
2. **"Sign up"** pe click karo
3. Email, Password, Username daalo → Account bana lo
4. Email verify kar lo (inbox check karo)

---

## STEP 2: GitHub pe Code Upload Karo

1. GitHub mein login karo
2. **"+"** button pe click karo (top right corner mein) → **"New repository"**
3. Repository name mein likho: **machinetrack-pro**
4. **"Public"** select karo
5. ✅ Tick karo: **"Add a README file"**
6. **"Create repository"** pe click karo

Ab files upload karo:
1. Repository page pe **"Add file"** → **"Upload files"** pe click karo
2. Jo files maine aapko di hain (project folder), sab drag & drop kar do
3. **"Commit changes"** pe click karo

**IMPORTANT:** Folder structure aisi honi chahiye:
```
machinetrack-pro/
├── package.json
├── vite.config.js
├── index.html
└── src/
    ├── main.jsx
    ├── App.jsx
    └── firebase.js
```

---

## STEP 3: Firebase Setup Karo (Database ke liye)

### 3A: Firebase Project Banao
1. Browser mein jao: **https://console.firebase.google.com**
2. Google account se login karo
3. **"Create a project"** pe click karo
4. Project name daalo: **machinetrack-pro**
5. Google Analytics OFF kar do (zaroorat nahi)
6. **"Create project"** pe click karo
7. Wait karo... jab ready ho jaye toh **"Continue"** karo

### 3B: Realtime Database Banao
1. Left menu mein **"Build"** ke andar **"Realtime Database"** pe click karo
2. **"Create Database"** pe click karo
3. Location: **Singapore (asia-southeast1)** select karo (India ke paas hai)
4. **"Start in test mode"** select karo → **"Enable"**

### 3C: Firebase Config Copy Karo
1. Left menu mein **"Project Overview"** (gear icon) pe click karo
2. **"Project settings"** pe jao
3. Page neeche scroll karo → **"Your apps"** section mein
4. **"Web"** icon (</>) pe click karo
5. App nickname daalo: **machinetrack**
6. **"Register app"** pe click karo
7. Ab screen pe **firebaseConfig** dikhega — YEH IMPORTANT HAI!

Kuch aisa dikhega:
```
const firebaseConfig = {
  apiKey: "AIzaSyB...........",
  authDomain: "machinetrack-pro.firebaseapp.com",
  databaseURL: "https://machinetrack-pro-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "machinetrack-pro",
  storageBucket: "machinetrack-pro.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123def456"
};
```

**YEH SAARI VALUES COPY KARO!**

### 3D: Firebase Config File Update Karo
1. GitHub pe jao → apne repository mein
2. **src/firebase.js** file pe click karo
3. Pencil icon (✏️ Edit) pe click karo
4. Jo placeholder values hain unko apne Firebase config se replace karo:
   - `YAHAN_APNA_API_KEY_DAALEIN` → apna apiKey daalo
   - `YAHAN_APNA_PROJECT.firebaseapp.com` → apna authDomain daalo
   - `https://YAHAN_APNA_PROJECT-default-rtdb.firebaseio.com` → apna databaseURL daalo
   - `YAHAN_APNA_PROJECT_ID` → apna projectId daalo
   - `YAHAN_APNA_PROJECT.appspot.com` → apna storageBucket daalo
   - `YAHAN_SENDER_ID` → apna messagingSenderId daalo
   - `YAHAN_APP_ID` → apna appId daalo
5. **"Commit changes"** pe click karo

---

## STEP 4: Vercel pe Deploy Karo (Website Live Karo)

1. Browser mein jao: **https://vercel.com**
2. **"Sign Up"** pe click karo → **"Continue with GitHub"** select karo
3. GitHub permission de do
4. Dashboard pe **"Add New..."** → **"Project"** pe click karo
5. **"Import Git Repository"** mein apna **machinetrack-pro** dikhega → **"Import"** pe click karo
6. Settings kuch mat badlo, sab automatic detect ho jayega
7. **"Deploy"** pe click karo
8. 1-2 minute wait karo... 🎉 **DONE!**

Ab Vercel aapko ek URL dega jaise:
```
https://machinetrack-pro.vercel.app
```

**YEH URL APNI TEAM KO SHARE KARO!** 🚀

---

## STEP 5: Team Ko Access Do

1. Jo URL mila hai woh WhatsApp group mein bhej do
2. Sabke phone aur computer pe chalega
3. **Real-time sync** — ek aadmi booking karega toh sabko turant dikhega

### Phone pe Shortcut Banao (App jaisa):
1. Phone mein Chrome se URL kholo
2. **3 dot menu** (⋮) pe click karo
3. **"Add to Home Screen"** pe click karo
4. Ab app icon jaisa dikhega home screen pe!

---

## Troubleshooting (Problem Aaye Toh)

### ❌ "Firebase Error" aaye
- firebase.js file check karo — sab values sahi copy hue hain?
- Firebase console mein Realtime Database "test mode" mein hai?

### ❌ Page blank aaye
- Vercel pe deployment check karo — koi error toh nahi?
- Browser console (F12) mein error dekho

### ❌ Data save nahi ho raha
- Firebase Realtime Database rules check karo — "test mode" mein hona chahiye
- Internet connection check karo

---

## 🔒 Security (Baad mein karna — Zaroori hai)

30 din baad Firebase "test mode" expire ho jayega. Tab yeh karo:

1. Firebase Console → Realtime Database → **Rules** tab
2. Yeh rules paste karo:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```
3. **"Publish"** pe click karo

(Production ke liye baad mein authentication add kar sakte hain — mujhse pooch lena)

---

## 💰 Cost (Kitna Kharcha)

| Service | Free Limit | Kaafi hai? |
|---------|-----------|------------|
| GitHub | Unlimited | ✅ Haan |
| Firebase | 1GB data, 10GB/month transfer | ✅ Haan (15 clinics ke liye kaafi) |
| Vercel | 100GB bandwidth/month | ✅ Haan |

**Total Cost: ₹0 (Bilkul FREE!)** 🎉

---

## Need Help?

Agar kahi pe atak jao toh mujhse poochh lena — main help kar dunga! 
Screenshots ke saath bata dunga har step. 🤝
